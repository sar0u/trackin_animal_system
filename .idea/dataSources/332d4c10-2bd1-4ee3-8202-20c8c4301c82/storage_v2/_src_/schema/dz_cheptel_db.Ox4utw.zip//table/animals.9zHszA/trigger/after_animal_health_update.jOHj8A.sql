create definer = root@localhost trigger after_animal_health_update
    after update
    on animals
    for each row
BEGIN
    IF NOT (OLD.health_status <=> NEW.health_status)
       OR NOT (OLD.weight <=> NEW.weight) THEN
        INSERT INTO audit_logs
            (action, entity_type, entity_id, old_values, new_values)
        VALUES (
            'Animal Health or Weight Update',
            'animals',
            OLD.id,
            JSON_OBJECT('health', OLD.health_status, 'weight', OLD.weight),
            JSON_OBJECT('health', NEW.health_status, 'weight', NEW.weight)
        );
    END IF;
END;

