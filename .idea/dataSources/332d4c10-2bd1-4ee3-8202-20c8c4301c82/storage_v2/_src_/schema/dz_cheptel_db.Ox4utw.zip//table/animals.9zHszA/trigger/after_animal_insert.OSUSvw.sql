create definer = root@localhost trigger after_animal_insert
    after insert
    on animals
    for each row
BEGIN
    IF NEW.rfid_tag_id IS NOT NULL THEN
        UPDATE rfid_tags
        SET tag_status = 'Assigned'
        WHERE id = NEW.rfid_tag_id;
    END IF;
END;

