create definer = root@localhost trigger after_animal_status_history
    after update
    on animals
    for each row
BEGIN
    IF NOT (OLD.life_status <=> NEW.life_status)
       OR NOT (OLD.health_status <=> NEW.health_status) THEN
        INSERT INTO animal_status_history
            (animal_id, old_life_status, new_life_status,
             old_health_status, new_health_status)
        VALUES
            (OLD.id, OLD.life_status, NEW.life_status,
             OLD.health_status, NEW.health_status);
    END IF;
END;

