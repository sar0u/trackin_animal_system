create definer = root@localhost trigger after_animal_status_update
    after update
    on animals
    for each row
BEGIN
    IF NEW.life_status IN ('Dead','Sold','Slaughtered')
       AND OLD.rfid_tag_id IS NOT NULL THEN
        UPDATE rfid_tags
        SET tag_status = 'InStock'
        WHERE id = OLD.rfid_tag_id;
    END IF;
END;

