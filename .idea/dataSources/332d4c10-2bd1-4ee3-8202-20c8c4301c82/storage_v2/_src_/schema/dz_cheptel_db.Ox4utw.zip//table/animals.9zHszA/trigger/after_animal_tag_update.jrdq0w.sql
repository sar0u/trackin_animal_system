create definer = root@localhost trigger after_animal_tag_update
    after update
    on animals
    for each row
BEGIN
    IF NOT (OLD.rfid_tag_id <=> NEW.rfid_tag_id) THEN
        IF OLD.rfid_tag_id IS NOT NULL THEN
            UPDATE rfid_tags SET tag_status = 'InStock' WHERE id = OLD.rfid_tag_id;
        END IF;
        IF NEW.rfid_tag_id IS NOT NULL THEN
            UPDATE rfid_tags SET tag_status = 'Assigned' WHERE id = NEW.rfid_tag_id;
        END IF;
    END IF;
END;

