create definer = root@localhost trigger before_animal_update_tag_check
    before update
    on animals
    for each row
BEGIN
    DECLARE v_tag_status VARCHAR(50);

    IF NEW.birth_date IS NOT NULL AND NEW.birth_date > CURDATE() THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Opération refusée : la date de naissance ne peut pas être dans le futur.';
    END IF;

    IF NEW.rfid_tag_id IS NOT NULL AND NOT (OLD.rfid_tag_id <=> NEW.rfid_tag_id) THEN
        SELECT tag_status INTO v_tag_status
        FROM rfid_tags WHERE id = NEW.rfid_tag_id;

        IF v_tag_status IS NULL THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Opération refusée : tag RFID introuvable.';
        END IF;

        IF v_tag_status <> 'InStock' THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Opération refusée : tag RFID non disponible.';
        END IF;
    END IF;
END;

