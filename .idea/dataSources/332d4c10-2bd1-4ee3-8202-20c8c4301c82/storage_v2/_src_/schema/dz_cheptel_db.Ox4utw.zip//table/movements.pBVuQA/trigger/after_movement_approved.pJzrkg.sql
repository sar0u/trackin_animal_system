create definer = root@localhost trigger after_movement_approved
    after update
    on movements
    for each row
BEGIN
    IF OLD.approval_status <> NEW.approval_status
       AND NEW.approval_status = 'Approved' THEN
        UPDATE animals
        SET farm_id = NEW.to_farm_id
        WHERE id = NEW.animal_id;
    END IF;
END;

