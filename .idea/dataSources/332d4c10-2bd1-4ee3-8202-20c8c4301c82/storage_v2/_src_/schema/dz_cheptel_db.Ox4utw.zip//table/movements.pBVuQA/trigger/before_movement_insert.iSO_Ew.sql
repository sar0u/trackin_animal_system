create definer = root@localhost trigger before_movement_insert
    before insert
    on movements
    for each row
BEGIN
    DECLARE v_status VARCHAR(50);

    SELECT life_status INTO v_status
    FROM animals WHERE id = NEW.animal_id;

    IF v_status IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Opération refusée : animal introuvable.';
    END IF;

    IF v_status <> 'Active' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Opération refusée : impossible de déplacer un animal non actif.';
    END IF;

    IF NEW.from_farm_id = NEW.to_farm_id THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Opération refusée : la ferme de départ et d\'arrivée doivent être différentes.';
    END IF;
END;

