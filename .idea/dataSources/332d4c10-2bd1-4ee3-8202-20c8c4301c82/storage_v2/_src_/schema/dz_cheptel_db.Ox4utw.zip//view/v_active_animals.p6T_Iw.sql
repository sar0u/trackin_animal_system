create definer = root@localhost view v_active_animals as
select `a`.`id`                                       AS `id`,
       `a`.`species`                                  AS `species`,
       `a`.`breed`                                    AS `breed`,
       `a`.`gender`                                   AS `gender`,
       `a`.`birth_date`                               AS `birth_date`,
       `a`.`weight`                                   AS `weight`,
       `a`.`health_status`                            AS `health_status`,
       `a`.`vaccination_status`                       AS `vaccination_status`,
       concat(`u`.`first_name`, ' ', `u`.`last_name`) AS `owner_name`,
       `f`.`name`                                     AS `farm_name`,
       `f`.`location`                                 AS `farm_location`,
       `rt`.`rfid_code`                               AS `rfid_code`
from (((`dz_cheptel_db`.`animals` `a` join `dz_cheptel_db`.`users` `u`
        on ((`u`.`id` = `a`.`owner_id`))) join `dz_cheptel_db`.`farms` `f`
       on ((`f`.`id` = `a`.`farm_id`))) left join `dz_cheptel_db`.`rfid_tags` `rt` on ((`rt`.`id` = `a`.`rfid_tag_id`)))
where (`a`.`life_status` = 'Active');

